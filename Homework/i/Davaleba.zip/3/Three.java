public class Three {
    public static void main(String[] args) {
        System.out.println(Integer.valueOf(args[0]) * Integer.valueOf(args[1]));
    }
}