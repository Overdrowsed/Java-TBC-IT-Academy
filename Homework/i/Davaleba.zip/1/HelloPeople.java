public class HelloPeople {
    public static void print() {
        System.out.println("HelloPeople");
    }
}